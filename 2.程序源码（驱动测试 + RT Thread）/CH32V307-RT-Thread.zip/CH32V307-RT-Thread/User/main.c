/********************************** (C) COPYRIGHT *******************************
* File Name          : main.c
* Author             : WCH
* Version            : V1.0.0
* Date               : 2020/04/30
* Description        : Main program body.
*********************************************************************************
* Copyright (c) 2021 Nanjing Qinheng Microelectronics Co., Ltd.
* Attention: This software (modified or not) and binary are used for 
* microcontroller manufactured by Nanjing Qinheng Microelectronics.
*******************************************************************************/
#include "ch32v30x.h"
#include <rtthread.h>
#include <rthw.h>
#include "drivers/pin.h"
#include <at24cxx.h>
#include "w25qxx.h"
#include "ili9341.h"
#include "key.h"

#define CPU_NAME_SIZE 16u

/* Global typedef */
typedef struct
{
    uint8_t Name[CPU_NAME_SIZE];
    // MCU��Ϣ
    uint32_t UID[3];        // оƬID
    uint16_t FlashCapacity; // Flash����
    uint16_t PageSize;      // ҳ��С
    RCC_ClocksTypeDef Freq; // MCU frequencyʱ��Ƶ��
    uint32_t ChipID;
#if defined(DRIVERS_W25QXX_H_)
    w25qxx_t *w25q;
#endif

#if defined(DRIVERS_ILI9341_H_)
    lcd_t *lcd;
#endif
} device_t;

/* Global define */
#define TEXT_ADDR        100
#define SIZE             sizeof(TEXT_Buffer)
#define SYS_DEBUG(fmt,...)      rt_kprintf(fmt,##__VA_ARGS__)

/* LED0 is driven by the pin driver interface of rt  */
#define LED0_PIN  18   //PC3

/* Global Variable */
const u8 TEXT_Buffer[] = {"CH32V30x I2C TEST"};

device_t pioneer;

#if defined(__GNUC__)
__attribute__((aligned(32))) const uint8_t soft_version[2] __attribute__((section(".rodata.SoftVersion"))) = {1, 0}; // ֻ���洢��
#endif

static void dev_show_info(device_t *dev);

/*********************************************************************
 * @fn      LED1_BLINK_INIT
 *
 * @brief   LED1 directly calls the underlying driver
 *
 * @return  none
 */
int led_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure={0};
    TIM_TimeBaseInitTypeDef TIM_TimeBaseInitStructure = {0};
    TIM_OCInitTypeDef TIM_OCInitStructure = {0};
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD | RCC_APB2Periph_TIM9 | RCC_APB2Periph_AFIO, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(GPIOD, &GPIO_InitStructure);

    GPIO_PinRemapConfig(GPIO_FullRemap_TIM9, ENABLE);

    TIM_TimeBaseInitStructure.TIM_Period = 100 - 1;
    TIM_TimeBaseInitStructure.TIM_Prescaler = 1440 - 1;
    TIM_TimeBaseInitStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseInitStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInitStructure.TIM_RepetitionCounter = 0;

    TIM_TimeBaseInit(TIM9, &TIM_TimeBaseInitStructure);

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;

    TIM_OC3Init(TIM9, &TIM_OCInitStructure);
    TIM_OC3PreloadConfig(TIM9, TIM_OCPreload_Disable);

    TIM_ARRPreloadConfig(TIM9,ENABLE);
    TIM_CtrlPWMOutputs(TIM9, ENABLE);
    TIM_Cmd(TIM9, ENABLE);
}
INIT_BOARD_EXPORT(led_init);

void led_entry(void *parameter){
    uint16_t pwm = 0,dir = 0;
    while(1)
    {
        /************************ �����Ʋ��� ***************************/
        if (dir == 0)
        {
            if (++pwm >= 100)
                dir = 1;
        }
        else
        {
            if (--pwm <= 0)
                dir = 0;
        }
        TIM_SetCompare3(TIM9, pwm);
        rt_thread_mdelay(5);
    }
}

void lcd_entry(void *parameter){
    uint8_t key;
//    uint8_t bl = 1;
    while (1)
    {
        key = key_scan(0);
        tftlcd.tp.scan(0);

        if (pioneer.lcd->tp.sta & TP_PRES_DOWN)      /* ������������ */
        {
            if (pioneer.lcd->tp.x[0] < pioneer.lcd->width && pioneer.lcd->tp.y[0] < pioneer.lcd->height)
            {
                if (pioneer.lcd->tp.x[0] > (pioneer.lcd->width - 24) && pioneer.lcd->tp.y[0] < 16)
                {
                    ili9341_clear(WHITE);                                                /* ���� */
                    pioneer.lcd->point_color = BLUE;
                    ili9341_show_string(pioneer.lcd->width - 24, 0, 200, 16, 16, "RST"); /* ��ʾ�������� */
                    pioneer.lcd->point_color = RED;
                }
                else
                {
                    tpad_draw_big_point(pioneer.lcd->tp.x[0], pioneer.lcd->tp.y[0], RED);   /* ���� */
                }
            }
        }

        if (key == WKUP_PRES)               /* KEY0����,��ִ��У׼���� */
        {
//            bl = !bl;
//            LCD_BL(bl);
            ili9341_clear(WHITE);               /* ���� */
            tpad_adjust();                    /* ��ĻУ׼ */
            tpad_save_adjust_param();
            ili9341_clear(WHITE);                                                /* ���� */
            pioneer.lcd->point_color = BLUE;
            ili9341_show_string(pioneer.lcd->width - 24, 0, 200, 16, 16, "RST"); /* ��ʾ�������� */
            pioneer.lcd->point_color = RED;
        }
        rt_thread_mdelay(3);
    }
}

/*********************************************************************
 * @fn      main
 *
 * @brief   main is just one of the threads, in addition to tshell,idle
 * This main is just a flashing LED, the main thread is registered in 
 * rtthread_startup, tshell uses the serial port to receive interrupts, 
 * and the interrupt stack and thread stack are used separately.
 *
 * @return  none
 */
int main(void)
{

//    uint8_t buffer[SIZE] = {0};
    SystemCoreClockUpdate();
    /* Pioneer ��Ϣ��� */
    dev_show_info(&pioneer);
    pioneer.lcd->tp.init();

    /* �������̴߳��� */
    rt_thread_t led_thread = rt_thread_create("led", led_entry, NULL, 256, 11, 10);
    if(led_thread != RT_NULL)
        rt_thread_startup(led_thread);

    /* LCD�̴߳��� */
    rt_thread_t lcd_thread = rt_thread_create("lcd", lcd_entry, NULL, 512, 9, 10);
    if(lcd_thread != RT_NULL)
        rt_thread_startup(lcd_thread);

//    LCD_BL(0);

	while(1)
	{
	    rt_thread_mdelay(5);
	}
}

/*********************************************************************
 * @fn      led
 *
 * @brief   Test using the driver interface to operate the I/O port
 *
 * @return  none
 */
int led(void)
{
    rt_uint8_t count;

    rt_pin_mode(LED0_PIN, PIN_MODE_OUTPUT);
    printf("led_SP:%08x\r\n",__get_SP());
    for(count = 0 ; count < 10 ;count++)
    {
        rt_pin_write(LED0_PIN, PIN_LOW);
        rt_kprintf("led on, count : %d\r\n", count);
        rt_thread_mdelay(500);

        rt_pin_write(LED0_PIN, PIN_HIGH);
        rt_kprintf("led off\r\n");
        rt_thread_mdelay(500);
    }
    return 0;
}

MSH_CMD_EXPORT(led,  led sample by using I/O drivers);

void dev_show_info(device_t *dev)
{
    /*          CH32V303CBT6-0x303305x4
    *          CH32V303RBT6-0x303205x4
    *          CH32V303RCT6-0x303105x4
    *          CH32V303VCT6-0x303005x4
    *          CH32V305FBP6-0x305205x8
    *          CH32V305RBT6-0x305005x8
    *          CH32V305GBU6-0x305B05x8
    *          CH32V307WCU6-0x307305x8
    *          CH32V307FBP6-0x307205x8
    *          CH32V307RCT6-0x307105x8
    *          CH32V307VCT6-0x307005x8
    *          CH32V317VCT6-0x3170B5X8
    *          CH32V317WCU6-0x3173B5X8
    *          CH32V317TCU6-0x3175B5X8
    */
    dev->ChipID = DBGMCU_GetCHIPID();
    switch(dev->ChipID){
        case 0x30700528:
            sprintf(dev->Name,"CH32V303VCT6");
            break;
        default :
            sprintf(dev->Name,"Unknow");
            break;
    }

    RCC_GetClocksFreq(&dev->Freq);

    SYS_DEBUG("\r\n----------------------------------------------------");
    SYS_DEBUG("\r\n-->>    MCU Name : %s\r\n", dev->Name);
    SYS_DEBUG("-->>    MCU ChipID = %08lX\r\n", dev->ChipID);
    SYS_DEBUG("-->>    MCU SYSCLK = %dMHz , HCLK = %dMHz , PCLK1 = %dMHz , PCLK2 = %dMHz\r\n",
              (uint8_t)(dev->Freq.SYSCLK_Frequency / 1000000),
              (uint8_t)(dev->Freq.HCLK_Frequency / 1000000),
              (uint8_t)(dev->Freq.PCLK1_Frequency / 1000000),
              (uint8_t)(dev->Freq.PCLK2_Frequency / 1000000));

    // ���W25QXX
#if defined(DRIVERS_W25QXX_H_)
    while (w25q_check());
    dev->w25q = &w25qxx;
#endif

#if defined(__AT24CXX_H_)
    if (at24cxx_check() == 0)
    {
        switch (EE_TYPE)
        {
        case AT24C01:
            SYS_DEBUG("-->>    EEPROM : AT24C01\r\n");
            break;
        case AT24C02:
            SYS_DEBUG("-->>    EEPROM : AT24C02\r\n");
            break;
        case AT24C04:
            SYS_DEBUG("-->>    EEPROM : AT24C04\r\n");
            break;
        case AT24C08:
            SYS_DEBUG("-->>    EEPROM : AT24C08\r\n");
            break;
        case AT24C16:
            SYS_DEBUG("-->>    EEPROM : AT24C16\r\n");
            break;
        case AT24C32:
            SYS_DEBUG("-->>    EEPROM : AT24C32\r\n");
            break;
        case AT24C64:
            SYS_DEBUG("-->>    EEPROM : AT24C64\r\n");
            break;
        case AT24C128:
            SYS_DEBUG("-->>    EEPROM : AT24C128\r\n");
            break;
        case AT24C256:
            SYS_DEBUG("-->>    EEPROM : AT24C256\r\n");
            break;
        default:
            SYS_DEBUG("-->>    EEPROM : unknow eeprom\r\n");
            break;
        }
    }
    else
        SYS_DEBUG("-->>    EEPROM : eeprom init failed\r\n");
#endif

#if defined(DRIVERS_ILI9341_H_)
    dev->lcd = &tftlcd;
    SYS_DEBUG("-->>    TFT-LCD ID : %#X\r\n", dev->lcd->id);
#endif

#if defined(LVGL_H)
    SYS_DEBUG("-->>    GUI : littleVGL %u.%u.%u\n", lv_version_major(), lv_version_minor(), lv_version_patch());
#endif

#if defined(__RT_THREAD_H__)
    // �ں���Ϣ
    SYS_DEBUG("-->>    Kernel : RT-Thread %u.%02u.%02u\r\n", RTTHREAD_VERSION / 10000, RTTHREAD_VERSION / 100 % 100, RTTHREAD_VERSION % 100);
#endif

    SYS_DEBUG("-->>    SoftVersion V%u.%02u\r\n", soft_version[0], soft_version[1]);
    SYS_DEBUG("-->>    SoftCompileTime : "__DATE__
          " "__TIME__
          "\r\n");
    SYS_DEBUG("----------------------------------------------------\r\n\r\n");
}

