/*
 * fsmc.h
 *
 *  Created on: 2024��11��19��
 *      Author: WangMC
 */

#ifndef DRIVERS_FSMC_H_
#define DRIVERS_FSMC_H_

#include "ch32v30x.h"
#include "ili9341.h"

// LCD��Ӧ��FSMC�ĵ�ַ�ṹ��
typedef struct
{
    __IO uint16_t reg;  // ILI9341����
    __IO uint16_t data; // ILI9341����
} fsmc_to_lcd_t;

#define LCD_FSMC_AX          19         /* ʹ��FSMC_A19��LCD_RS */

#define LCD_BASE        (uint32_t)(0X60000000 | (((1 << LCD_FSMC_AX) * 2) -2))
#define TFTLCD ((fsmc_to_lcd_t *)LCD_BASE)

void lcd_write_reg(vu16 reg);
void lcd_write_data(vu16 data);
uint16_t lcd_read_data(void);
void lcd_write_reg_data(uint16_t reg, uint16_t value);
uint16_t lcd_read_reg_data(uint16_t reg);
void lcd_write_gram_reg(void);
void lcd_write_gram_color(uint16_t rgb_code);

void fsmc_init(void);


#endif /* DRIVERS_FSMC_H_ */
