/*
 * w25qxx.c
 *
 *  Created on: 2024��11��19��
 *      Author: WangMC
 */


/*
 * @Author: MC Wang @ GDUT
 * @Date: 2024-03-13 20:29:34
 * @LastEditTime: 2024-05-02 00:27:41
 * @Description:
 * @FilePath: \AIBE_V1.4\Hardwares\src\w25qxx.c
 *
 */
#include "w25qxx.h"
#include <rtthread.h>

#define W25QXX_DEBUG(fmt, ...) rt_kprintf(fmt, ##__VA_ARGS__)

w25qxx_t w25qxx;

// ��ʼ��SPI FLASH��IO��
int w25q_init(void)
{
    uint8_t temp;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIO_InitStructure);    /* CS����ģʽ����(�������) */

    W25QXX_CS(1);                                  // SPI FLASH��ѡ��
    hw_spi2_init();                                 // ��ʼ��SPI
    hw_spi_setspeed(W25QXX_SPI, SPI_SPEED_4);       // ����Ϊ18Mʱ��

    w25qxx.id = w25q_read_id();
    if(w25qxx.id == F6_ID){
        temp = w25q_read_sr(3);              /* ��ȡ״̬�Ĵ���3���жϵ�ַģʽ */

        if ((temp & 0X01) == 0)              /* �������4�ֽڵ�ַģʽ,�����4�ֽڵ�ַģʽ */
        {
            w25q_write_en();                 /* дʹ�� */
            temp |= 1 << 1;                  /* ADP=1, �ϵ�4λ��ַģʽ */
            w25q_write_sr(3, temp);          /* дSR3 */

            W25QXX_CS(0);
            hw_spi_transport_byte(W25QXX_SPI,EN_4BYTE);    /* ʹ��4�ֽڵ�ַָ�� */
            W25QXX_CS(1);
        }
    }

    return 0;
}
INIT_BOARD_EXPORT(w25q_init);

// SPI Flash �Լ�
// ���أ�0-�ɹ���1-ʧ��
// ˵�����Լ�����õ�Flash��ʼ��һ������4K��ÿ�β��Զ���������ݣ����Ե�һ���������洢��
uint8_t w25q_check(void)
{
    uint16_t i;
    uint8_t buffer[32];

    w25q_erase_sector(W25QXX_CHECK_ADDR);                        // ����һ������
    w25q_read_buffer(buffer, W25QXX_CHECK_ADDR, sizeof(buffer)); // ��ȡһ��buffer����
    for (i = 0; i < sizeof(buffer); i++)
    {
        if (buffer[i] != 0xFF)
            return 1;
        buffer[i] = i;
    }

    w25q_write_buffer(buffer, W25QXX_CHECK_ADDR, sizeof(buffer)); // д��buffer����
    memset(buffer, 0, sizeof(buffer));
    w25q_read_buffer(buffer, W25QXX_CHECK_ADDR, sizeof(buffer)); // ��ȡһ��buffer����
    for (i = 0; i < sizeof(buffer); i++)
    {
        if (buffer[i] != i)
            return 1;
    }

    w25qxx.status = 1;
    w25qxx.devid = w25q_read_devid();

    w25qxx_info(&w25qxx);

    return 0; // �Լ�ͨ��
}

uint32_t w25q_read_id(void)
{
    uint32_t id, temp[3] = {0};
    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    hw_spi_transport_byte(W25QXX_SPI, RD_ID); // ���Ϳ�����0X9F

    /* Read 3 byte from the FLASH */
    for (u8 i = 0; i < 3; i++)
    {
        /* code */
        temp[i] = hw_spi_transport_byte(W25QXX_SPI, Dummy_Byte);
    }

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);

    id = (temp[0] << 16) | (temp[1] << 8) | temp[2];

    return id;
}

uint32_t w25q_read_devid(void)
{
    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    hw_spi_transport_byte(W25QXX_SPI, W25X_DeviceID); // ���Ϳ�����0XAB

    /* Read 3 byte from the FLASH */
    for (u8 i = 0; i < 3; i++)
    {
        /* code */
        hw_spi_transport_byte(W25QXX_SPI, Dummy_Byte);
    }

    uint32_t device_id = hw_spi_transport_byte(W25QXX_SPI, Dummy_Byte);

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);
    // ����4���ֽ�ΪDeviceID
    return device_id;
}

uint8_t w25q_read_sr(uint8_t regno)
{
    // ״̬�Ĵ���
    uint8_t sr = 0,command;
    switch (regno)
    {
        case 1:
            command = RD_SR1;     /* ��״̬�Ĵ���1ָ�� */
            break;

        case 2:
            command = RD_SR2;     /* ��״̬�Ĵ���2ָ�� */
            break;

        case 3:
            command = RD_SR3;     /* ��״̬�Ĵ���3ָ�� */
            break;

        default:
            command = RD_SR1;
            break;
    }

    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send "Read Status Register" instruction */
    hw_spi_transport_byte(W25QXX_SPI, command);

    sr = hw_spi_transport_byte(W25QXX_SPI, Dummy_Byte);

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);

    return sr;
}

void w25q_write_envsr(void)
{
    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send "Write Enable For Volatile Status Register" instruction */
    hw_spi_transport_byte(W25QXX_SPI, E_WSR);

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);
}

void w25q_write_sr(uint8_t regno,uint8_t data)
{
    uint8_t command;
    switch (regno)
    {
        case 1:
            command = WR_SR1;     /* ��״̬�Ĵ���1ָ�� */
            break;

        case 2:
            command = WR_SR2;     /* ��״̬�Ĵ���2ָ�� */
            break;

        case 3:
            command = WR_SR3;     /* ��״̬�Ĵ���3ָ�� */
            break;

        default:
            command = WR_SR1;
            break;
    }
    w25q_write_envsr();

    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send "Write Status Register" instruction */
    hw_spi_transport_byte(W25QXX_SPI, command);

    hw_spi_transport_byte(W25QXX_SPI, data);

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);
}

void w25q_write_en(void)
{
    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send "Write Enable" instruction */
    hw_spi_transport_byte(W25QXX_SPI, WR_EN);

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);
}

void w25q_wait_write_end(void)
{
    uint8_t FLASH_Status = 0;
    uint16_t over_time = 0;

    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send "Read Status Register" instruction */
    hw_spi_transport_byte(W25QXX_SPI, RD_SR1);

    /* Loop as long as the memory is busy with a write cycle */
    do
    {
        /* Send a dummy byte to generate the clock needed by the FLASH
        and put the value of the status register in FLASH_Status variable */
        FLASH_Status = hw_spi_transport_byte(W25QXX_SPI, Dummy_Byte);

        over_time++;

        if (over_time > 10000)
        {
            break;
        }
    } while ((FLASH_Status & WIP_Flag) == SET); /* Write in progress */

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);
}

void w25q_write_page(uint8_t *pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
    // ��д����
    w25q_write_sr(1,MM_PROTECT_NO);
    // ����дʹ��
    w25q_write_en();

    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    hw_spi_transport_byte(W25QXX_SPI, WRITE);

    /****************************************************************/
    if(w25qxx.id == F6_ID)
            hw_spi_transport_byte(W25QXX_SPI, (WriteAddr & 0xFF000000) >> 24);
    /* Send WriteAddr high nibble address byte to write to */
    hw_spi_transport_byte(W25QXX_SPI, (WriteAddr & 0xFF0000) >> 16);
    /* Send WriteAddr medium nibble address byte to write to */
    hw_spi_transport_byte(W25QXX_SPI, (WriteAddr & 0xFF00) >> 8);
    /* Send WriteAddr low nibble address byte to write to */
    hw_spi_transport_byte(W25QXX_SPI, WriteAddr & 0xFF);
    /*****************************************************************/

    /* Send the current byte */
    for (uint16_t i = 0; i < NumByteToWrite; i++)
        hw_spi_transport_byte(W25QXX_SPI, pBuffer[i]);

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);

    // �ȴ�д����
    w25q_wait_write_end();

    // ��д����
    w25q_write_sr(1,MM_PROTECT_ALL);

    // �ȴ�д����
    w25q_wait_write_end();
}

void w25q_write_buffer(uint8_t *pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite)
{
    uint16_t pageremain;
    pageremain = 256 - WriteAddr % 256; // ��ҳʣ����ֽ���

    if (NumByteToWrite <= pageremain)
        pageremain = NumByteToWrite; // ������256���ֽ�

    while (1)
    {
        w25q_write_page(pBuffer, WriteAddr, pageremain);

        if (NumByteToWrite == pageremain)
            break; // д�������
        else       // NumByteToWrite > pageremain
        {
            pBuffer += pageremain;
            WriteAddr += pageremain;

            NumByteToWrite -= pageremain; // ��ȥ�Ѿ�д���˵��ֽ���

            if (NumByteToWrite >= 256)
                pageremain = 256; // һ�ο���д��256���ֽ�
            else
                pageremain = NumByteToWrite; // ����256���ֽ���
        }
    }
}

void w25q_read_buffer(uint8_t *pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead)
{
    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send "Read from Memory " instruction */
    hw_spi_transport_byte(W25QXX_SPI, READ);

    if(w25qxx.id == F6_ID)
        hw_spi_transport_byte(W25QXX_SPI, (ReadAddr & 0xFF000000) >> 24);
    /* Send ReadAddr high nibble address byte to read from */
    hw_spi_transport_byte(W25QXX_SPI, (ReadAddr & 0xFF0000) >> 16);
    /* Send ReadAddr medium nibble address byte to read from */
    hw_spi_transport_byte(W25QXX_SPI, (ReadAddr & 0xFF00) >> 8);
    /* Send ReadAddr low nibble address byte to read from */
    hw_spi_transport_byte(W25QXX_SPI, ReadAddr & 0xFF);

    while (NumByteToRead--) /* while there is data to be read */
    {
        /* Read a byte from the FLASH */
        *pBuffer = hw_spi_transport_byte(W25QXX_SPI, Dummy_Byte);
        /* Point to the next location where the byte read will be saved */
        pBuffer++;
    }

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);
}

void w25q_hspeed_read_buffer(uint8_t *pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead)
{
    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send "Read from Memory " instruction */
    hw_spi_transport_byte(W25QXX_SPI, HS_READ);

    /* Send ReadAddr high nibble address byte to read from */
    hw_spi_transport_byte(W25QXX_SPI, (ReadAddr & 0xFF0000) >> 16);
    /* Send ReadAddr medium nibble address byte to read from */
    hw_spi_transport_byte(W25QXX_SPI, (ReadAddr & 0xFF00) >> 8);
    /* Send ReadAddr low nibble address byte to read from */
    hw_spi_transport_byte(W25QXX_SPI, ReadAddr & 0xFF);

    hw_spi_transport_byte(W25QXX_SPI, Dummy_Byte); // �ȴ�һ��Dummy_Byte

    while (NumByteToRead--) /* while there is data to be read */
    {
        /* Read a byte from the FLASH */
        *pBuffer = hw_spi_transport_byte(W25QXX_SPI, Dummy_Byte);
        /* Point to the next location where the byte read will be saved */
        pBuffer++;
    }

    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);
}

void w25q_erase_sector(uint32_t SectorAddr)
{
    w25q_write_sr(1,MM_PROTECT_NO); // ��д����

    /* Send write enable instruction */
    w25q_write_en();

    /* Sector Erase */
    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send Sector Erase instruction */
    hw_spi_transport_byte(W25QXX_SPI, SE_4K);
    if(w25qxx.id == F6_ID)
        hw_spi_transport_byte(W25QXX_SPI, (SectorAddr & 0xFF000000) >> 24);
    /* Send SectorAddr high nibble address byte */
    hw_spi_transport_byte(W25QXX_SPI, (SectorAddr & 0xFF0000) >> 16);
    /* Send SectorAddr medium nibble address byte */
    hw_spi_transport_byte(W25QXX_SPI, (SectorAddr & 0xFF00) >> 8);
    /* Send SectorAddr low nibble address byte */
    hw_spi_transport_byte(W25QXX_SPI, SectorAddr & 0xFF);
    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);

    /* Wait the end of Flash writing */
    w25q_wait_write_end();

    w25q_write_sr(1,MM_PROTECT_ALL); // ��д����

    // �ȴ�д����
    w25q_wait_write_end();
}

void w25q_erase_chip(void)
{
    w25q_write_sr(1,MM_PROTECT_NO); // ��д����

    /* Send write enable instruction */
    w25q_write_en();

    /* Chip Erase */
    /* Select the FLASH: Chip Select low */
    W25QXX_CS(0);

    /* Send Chip Erase instruction  */
    hw_spi_transport_byte(W25QXX_SPI, BE);
    /* Deselect the FLASH: Chip Select high */
    W25QXX_CS(1);

    /* Wait the end of Flash writing */
    w25q_wait_write_end();

    w25q_write_sr(1,MM_PROTECT_ALL); // ��д����

    /* Wait the end of Flash writing */
    w25q_wait_write_end();
}

void w25qxx_info(w25qxx_t *info)
{
    switch (info->id)
    {
    case F1_ID:
        W25QXX_DEBUG("-->>    ExtFlash : %s", F1_FLASH);
        break;

    case F2_ID:
        W25QXX_DEBUG("-->>    ExtFlash : %s", F2_FLASH);
        break;

    case F3_ID:
        W25QXX_DEBUG("-->>    ExtFlash : %s", F3_FLASH);
        break;

    case F4_ID:
        W25QXX_DEBUG("-->>    ExtFlash : %s", F4_FLASH);
        break;

    case F5_ID:
        W25QXX_DEBUG("-->>    ExtFlash : %s", F5_FLASH);
        break;

    case F6_ID:
        W25QXX_DEBUG("-->>    ExtFlash : %s", F6_FLASH);
        break;

    default:
        W25QXX_DEBUG("-->>    unknown FLASH\r\n");
        return;
    }
    W25QXX_DEBUG(" , ID = %#010lX", info->id);
    W25QXX_DEBUG(" , DeviceID = %#010lX\r\n", info->devid);
}
