/*
 * key.c
 *
 *  Created on: 2024��11��19��
 *      Author: WangMC
 */
#include "key.h"
#include <rtthread.h>

int key_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    return 0;
}
INIT_BOARD_EXPORT(key_init);

uint8_t key_scan(uint8_t mode)
{
    static uint8_t key_up = 1; // �������ɿ���־
    if (mode)
        key_up = 1; // ֧������
    if (key_up && (/* KEY == 0 || */WK_UP == 0))
    {
        for (uint32_t i = 0; i < 12 * 1000 * 10; i++)
            ;
        key_up = 0;
//        if (KEY == 0)
//            return 1;
        if (WK_UP == 0)
            return WKUP_PRES;
    }
    else if (/* KEY == 1 && */WK_UP == 0)
        key_up = 1;
    return 0; // �ް�������
}

