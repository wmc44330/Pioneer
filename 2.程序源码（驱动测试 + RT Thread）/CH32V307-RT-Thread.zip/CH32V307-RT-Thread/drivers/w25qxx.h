/*
 * w25qxx.h
 *
 *  Created on: 2024��11��19��
 *      Author: WangMC
 */

#ifndef DRIVERS_W25QXX_H_
#define DRIVERS_W25QXX_H_

#include "ch32v30x.h"
#include <stdio.h>
#include <string.h>
#include "spi.h"

typedef struct
{
    uint8_t status;
    uint32_t id;
    uint32_t devid;
} w25qxx_t;

// FLASH��������
#define WRITE 0x02 /* Write to Memory instruction */
#define E_WSR 0x50 /* Enable-Volatile-Write-Status-Register */

#define WR_SR1 0x01 /* Write Status Register 1 instruction */
#define WR_SR2 0x31 /* Write Status Register 2 instruction */
#define WR_SR3 0x11 /* Write Status Register 3 instruction */

#define WR_EN 0x06 /* Write enable instruction */

#define READ 0x03    /* Read from Memory instruction */
#define HS_READ 0x0B /* Fast Read from Memory instruction */

#define RD_SR1 0x05   /* Read Status Register 1 instruction  */
#define RD_SR2 0x35   /* Read Status Register 2 instruction  */
#define RD_SR3 0x15   /* Read Status Register 3 instruction  */

#define RD_ID 0x9F   /* Read identification */
#define SE_4K 0x20   /* 4K Sector Erase instruction */
#define BE 0xC7      /* chip Erase instruction */
#define W25X_DeviceID 0xAB

#define EN_4BYTE       0xB7

// ״̬�Ĵ���
#define WIP_Flag 0x01       /* Write In Progress (WIP) flag æ��־*/
#define MM_PROTECT_NO 0x00  // BP3=BP2=BP1=BP0=0;��д����
#define MM_PROTECT_ALL 0x0C // BP3=BP2=BP1=BP0=1;д����ȫ��
#define BPL_PROTECT_R 0x80  // BP3 BP2 BP1 BP0 ֻ��
#define BPL_PROTECT_RW 0x00 // BP3 BP2 BP1 BP0 ������д

#define Dummy_Byte 0xFF

#define W25QXX_CS(x)                do{ x ? \
                                          GPIO_SetBits(GPIOB, GPIO_Pin_12) : \
                                          GPIO_ResetBits(GPIOB, GPIO_Pin_12); \
                                    }while(0)
#define W25QXX_SPI SPI2

int w25q_init(void);
uint32_t w25q_read_id(void);
uint32_t w25q_read_devid(void);
uint8_t w25q_read_sr(uint8_t regno);
void w25q_write_envsr(void);
void w25q_write_sr(uint8_t regno,uint8_t data);
void w25q_write_en(void);
void w25q_wait_write_end(void);
void w25q_write_page(uint8_t *pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite);
void w25q_write_buffer(uint8_t *pBuffer, uint32_t WriteAddr, uint16_t NumByteToWrite);
void w25q_read_buffer(uint8_t *pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead);
void w25q_hspeed_read_buffer(uint8_t *pBuffer, uint32_t ReadAddr, uint16_t NumByteToRead);
void w25q_erase_sector(uint32_t SectorAddr);
void w25q_erase_chip(void);
void w25qxx_info(w25qxx_t *info);
uint8_t w25q_check(void);

#define W25QXX_CHECK_ADDR 0x000000 /* 0x000000-0x000FFF ռ4K �����洢�� */

// 25Q80 1M Bytes
#define F1_ID 0x00C84014
#define F1_DEVICE_ID 0x00000013
#define F1_FLASH "25Q80 1M"
// 25Q16 2M Bytes
#define F2_ID 0x00EF4015
#define F2_DEVICE_ID 0x00000014
#define F2_FLASH "25Q16 2M"
// 25Q32 4M Bytes
#define F3_ID 0x00EF4016
#define F3_DEVICE_ID 0x00000015
#define F3_FLASH "25Q32 4M"
// 25Q64 8M Bytes
#define F4_ID 0x00EF4017
#define F4_DEVICE_ID 0x00000016
#define F4_FLASH "25Q64 8M"
// 25Q128 16M Bytes
#define F5_ID 0x00EF4018
#define F5_DEVICE_ID 0x00000017
#define F5_FLASH "25Q128 16M"
// 25Q256 32M Bytes
#define F6_ID 0x00EF4019
#define F6_DEVICE_ID 0x00000018
#define F6_FLASH "25Q256 32M"

extern w25qxx_t w25qxx;


#endif /* DRIVERS_W25QXX_H_ */
