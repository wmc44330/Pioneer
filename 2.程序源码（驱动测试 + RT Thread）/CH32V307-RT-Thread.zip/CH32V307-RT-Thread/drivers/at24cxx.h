#ifndef __AT24CXX_H_
#define __AT24CXX_H_

#include "ch32v30x.h"

#define AT24C01     127
#define AT24C02     255
#define AT24C04     511
#define AT24C08     1023
#define AT24C16     2047
#define AT24C32     4095
#define AT24C64     8191
#define AT24C128    16383
#define AT24C256    32767

/* ������ʹ�õ���24c02�����Զ���EE_TYPEΪAT24C02 */

#define EE_TYPE     AT24C256

int at24cxx_init(void);
u8 at24cxx_read_byte(u16 ReadAddr);
void at24cxx_write_byte(u16 WriteAddr, u8 DataToWrite);
void at24cxx_read_multi_bytes(u16 ReadAddr, u8 *pBuffer, u16 NumToRead);
void at24cxx_write_multi_bytes(u16 WriteAddr, u8 *pBuffer, u16 NumToWrite);
u8 at24cxx_check(void);

#endif
