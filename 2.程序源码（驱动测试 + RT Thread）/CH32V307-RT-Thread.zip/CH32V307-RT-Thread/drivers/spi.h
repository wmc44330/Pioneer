/**
 ****************************************************************************************************
 * @file        spi.h
 * @author      ����ԭ���Ŷ�(ALIENTEK)
 * @version     V1.0
 * @date        2023-07-20
 * @brief       SPI ��������
 * @license     Copyright (c) 2020-2032, �������������ӿƼ����޹�˾
 ****************************************************************************************************
 * @attention
 *
 * ʵ��ƽ̨:����ԭ�� CH32V307������
 * ������Ƶ:www.yuanzige.com
 * ������̳:www.openedv.com
 * ��˾��ַ:www.alientek.com
 * �����ַ:openedv.taobao.com
 *
 * �޸�˵��
 * V1.0 20230720
 * ��һ�η���
 *
 ****************************************************************************************************
 */

#ifndef __SPI_H
#define __SPI_H

#include "ch32v30x.h"


/******************************************************************************************/

/* SPI2���� ���� */
#define SPI2_SCK_GPIO_PORT              GPIOB
#define SPI2_SCK_GPIO_PIN               GPIO_Pin_13
#define SPI2_SCK_GPIO_CLK_ENABLE()      do{ RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); }while(0)   /* PB��ʱ��ʹ�� */

#define SPI2_T_MISO_GPIO_PORT             GPIOB
#define SPI2_T_MISO_GPIO_PIN              GPIO_Pin_14
#define SPI2_T_MISO_GPIO_CLK_ENABLE()     do{ RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); }while(0)   /* PB��ʱ��ʹ�� */

#define SPI2_MOSI_GPIO_PORT             GPIOB
#define SPI2_MOSI_GPIO_PIN              GPIO_Pin_15
#define SPI2_MOSI_GPIO_CLK_ENABLE()     do{ RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE); }while(0)   /* PB��ʱ��ʹ�� */

/* SPI2��ض��� */
#define SPI2_SPI                        SPI2
#define SPI2_SPI_CLK_ENABLE()           do{ RCC_APB1PeriphClockCmd(RCC_APB1Periph_SPI2, ENABLE); }while(0)    /* SPI2ʱ��ʹ�� */

/* ���败��������IC T_PEN/T_CS/T_MISO/T_MOSI/T_SCK ���Ŷ��� */
#define T_PEN_GPIO_PORT                 GPIOE
#define T_PEN_GPIO_PIN                  GPIO_Pin_4
#define T_PEN_GPIO_CLK_ENABLE()         do{RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);}while(0)   /* PEN IO��ʱ��ʹ�� */

#define T_CS_GPIO_PORT                  GPIOB
#define T_CS_GPIO_PIN                   GPIO_Pin_1
#define T_CS_GPIO_CLK_ENABLE()          do{RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);}while(0)   /* CS IO��ʱ��ʹ�� */

#define T_MISO_GPIO_PORT                GPIOD
#define T_MISO_GPIO_PIN                 GPIO_Pin_6
#define T_MISO_GPIO_CLK_ENABLE()        do{RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOD, ENABLE);}while(0)   /* MISO IO��ʱ��ʹ�� */

#define T_MOSI_GPIO_PORT                GPIOE
#define T_MOSI_GPIO_PIN                 GPIO_Pin_6
#define T_MOSI_GPIO_CLK_ENABLE()        do{RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);}while(0)   /* MOSI IO��ʱ��ʹ�� */

#define T_CLK_GPIO_PORT                 GPIOE
#define T_CLK_GPIO_PIN                  GPIO_Pin_5
#define T_CLK_GPIO_CLK_ENABLE()         do{RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOE, ENABLE);}while(0)   /* CLK IO��ʱ��ʹ�� */

/******************************************************************************************/

/******************************************************************************************/
#define T_MOSI(x)       do{ x ? \
                            GPIO_SetBits(T_MOSI_GPIO_PORT, T_MOSI_GPIO_PIN) : \
                            GPIO_ResetBits(T_MOSI_GPIO_PORT, T_MOSI_GPIO_PIN); \
                        }while(0)       /* T_MOSI */

#define T_CLK(x)        do{ x ? \
                            GPIO_SetBits(T_CLK_GPIO_PORT, T_CLK_GPIO_PIN) : \
                            GPIO_ResetBits(T_CLK_GPIO_PORT, T_CLK_GPIO_PIN); \
                        }while(0)       /* T_CLK */

#define T_CS(x)         do{ x ? \
                            GPIO_SetBits(T_CS_GPIO_PORT, T_CS_GPIO_PIN) : \
                            GPIO_ResetBits(T_CS_GPIO_PORT, T_CS_GPIO_PIN); \
                        }while(0)       /* T_CS */

/* ���败������������ */
#define T_PEN           GPIO_ReadInputDataBit(T_PEN_GPIO_PORT, T_PEN_GPIO_PIN)           /* T_PEN */
#define T_MISO          GPIO_ReadInputDataBit(T_MISO_GPIO_PORT, T_MISO_GPIO_PIN)         /* T_MISO */

/******************************************************************************************/

/* SPI�����ٶ����� */
#define SPI_SPEED_2         0
#define SPI_SPEED_4         1
#define SPI_SPEED_8         2
#define SPI_SPEED_16        3
#define SPI_SPEED_32        4
#define SPI_SPEED_64        5
#define SPI_SPEED_128       6
#define SPI_SPEED_256       7

/******************************************************************************************/

void hw_spi2_init(void);                           /* SPI2��ʼ�� */
void hw_spi_setspeed(SPI_TypeDef *SPIx,uint8_t speed);             /* SPI2�ٶ����� */
uint8_t hw_spi_transport_byte(SPI_TypeDef *SPIx,uint8_t txdata);   /* SPI2��д�ֽ� */
void sw_spi_init(void);
void sw_spi_transport_byte(uint8_t data);

#endif

