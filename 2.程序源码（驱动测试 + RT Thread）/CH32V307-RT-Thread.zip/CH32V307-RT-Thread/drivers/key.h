/*
 * key.h
 *
 *  Created on: 2024��11��19��
 *      Author: WangMC
 */

#ifndef DRIVERS_KEY_H_
#define DRIVERS_KEY_H_

#include "ch32v30x.h"

#define WK_UP GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0)         /* T_T_MISO */

int key_init(void);
uint8_t key_scan(uint8_t mode);

#define KEY_PRES 1
#define WKUP_PRES 2

#endif /* DRIVERS_KEY_H_ */
