/*
 * xtp2046.c
 *
 *  Created on: 2024��11��20��
 *      Author: WangMC
 */
#include "xpt2046.h"
#include <stdlib.h>
#include <math.h>
#include "ili9341.h"
#include <rtthread.h>
#include "key.h"

// Ĭ��Ϊtouchtype=0������.
uint8_t CMD_RDX = 0XD0;
uint8_t CMD_RDY = 0X90;

void tp_delay(uint32_t timeout){
#if defined (__RT_THREAD_H__)
    if(rt_thread_self())
        rt_enter_critical();
#endif
    while (timeout--)
    {
        for (__IO uint8_t i = 0; i < 10; i++)
            ;
    }
#if defined (__RT_THREAD_H__)
    if(rt_thread_self())
        rt_exit_critical();
#endif
}

uint8_t tpad_init(void)
{
    sw_spi_init();
    tpad_read_x_and_y(&tftlcd.tp.x[0], &tftlcd.tp.y[0]);
    // ��ʼ��AT24C64
    at24cxx_init();
    if ((WK_UP == 1) && tpad_get_adjust_param())
        return 0; // �Ѿ�У׼
    else          // δУ׼?
    {
        ili9341_clear(WHITE); // ����
        tpad_adjust();        // ��ĻУ׼
        tpad_save_adjust_param();
    }
    tpad_get_adjust_param();
    return 1;
}

uint16_t xpt2046_read_adc(uint8_t cmd)
{
    uint8_t count = 0;
    uint16_t data = 0;
    T_CLK(0);                    // ������ʱ��
    T_MOSI(0);                   // ����������
    T_CS(0);                   // ѡ�д�����IC
    sw_spi_transport_byte(cmd); // ����������
    tp_delay(6);                // ADS7846��ת��ʱ���Ϊ6us
    T_CLK(0);
    tp_delay(1);
    T_CLK(1); // ��1��ʱ�ӣ����BUSY
    tp_delay(1);
    T_CLK(0);
    // ��λ����
    for (count = 0; count < 16; count++) // ����16λ����,ֻ�и�12λ��Ч
    {
        data <<= 1;
        T_CLK(0); // �½�����Ч
        tp_delay(1);
        T_CLK(1);
        if (T_MISO)
            data++;
    }
    data >>= 4; // ֻ�и�12λ��Ч.
    T_CS(1);   // �ͷ�Ƭѡ
    return (data);
}

uint16_t tpad_read_x_or_y(uint8_t xy)
{
#define READ_TIMES 5 // ��ȡ����
#define LOST_VAL 1   // ����ֵ
    uint16_t i, j;
    uint16_t buf[READ_TIMES];
    uint16_t sum = 0;
    uint16_t temp;
    for (i = 0; i < READ_TIMES; i++)
        buf[i] = xpt2046_read_adc(xy);
    for (i = 0; i < READ_TIMES - 1; i++) // ����
    {
        for (j = i + 1; j < READ_TIMES; j++)
        {
            if (buf[i] > buf[j]) // ��������
            {
                temp = buf[i];
                buf[i] = buf[j];
                buf[j] = temp;
            }
        }
    }
    sum = 0;
    for (i = LOST_VAL; i < READ_TIMES - LOST_VAL; i++)
        sum += buf[i];
    temp = sum / (READ_TIMES - 2 * LOST_VAL);
    return temp;
}

uint8_t tpad_read_x_and_y(uint16_t *x, uint16_t *y)
{
    uint16_t xtemp, ytemp;
    xtemp = tpad_read_x_or_y(CMD_RDX);
    ytemp = tpad_read_x_or_y(CMD_RDY);
    // if(xtemp<100||ytemp<100)return 0;//����ʧ��
    *x = xtemp;
    *y = ytemp;
    return 1; // �����ɹ�
}

uint8_t tpad_read_x_and_y_average(uint16_t *x, uint16_t *y)
{
#define ERR_RANGE 50 // ��Χ
    uint16_t x1, y1;
    uint16_t x2, y2;
    uint8_t flag;
    flag = tpad_read_x_and_y(&x1, &y1);
    if (flag == 0)
        return (0);
    flag = tpad_read_x_and_y(&x2, &y2);
    if (flag == 0)
        return (0);
    if (((x2 <= x1 && x1 < x2 + ERR_RANGE) || (x1 <= x2 && x2 < x1 + ERR_RANGE)) // ǰ�����β�����+-50��
        && ((y2 <= y1 && y1 < y2 + ERR_RANGE) || (y1 <= y2 && y2 < y1 + ERR_RANGE)))
    {
        *x = (x1 + x2) / 2;
        *y = (y1 + y2) / 2;
        return 1;
    }
    else
        return 0;
}

void tpad_save_adjust_param(void)
{
    int32_t temp;
    rt_thread_mdelay(10);
    // ����У�����!
    temp = tftlcd.tp.xfac * 100000000; // ����xУ������
    at24cxx_write_multi_bytes(SAVE_ADDR_BASE, (u8 *)&temp, 4);
    rt_thread_mdelay(10);
    temp = tftlcd.tp.yfac * 100000000; // ����yУ������
    at24cxx_write_multi_bytes(SAVE_ADDR_BASE + 4, (u8 *)&temp, 4);
    rt_thread_mdelay(10);
    // ����xƫ����
    at24cxx_write_multi_bytes(SAVE_ADDR_BASE + 8, (u8 *)&tftlcd.tp.xoff, 2);
    rt_thread_mdelay(10);
    // ����yƫ����
    at24cxx_write_multi_bytes(SAVE_ADDR_BASE + 10, (u8 *)&tftlcd.tp.yoff, 2);
    rt_thread_mdelay(10);
    // ���津������
    at24cxx_write_byte(SAVE_ADDR_BASE + 12, tftlcd.tp.type);
    rt_thread_mdelay(10);
    temp = 0X0A; // ���У׼����
    at24cxx_write_byte(SAVE_ADDR_BASE + 13, temp);
    rt_thread_mdelay(10);
}

uint8_t tpad_get_adjust_param(void)
{
    int32_t tempfac;
    tempfac = at24cxx_read_byte(SAVE_ADDR_BASE + 13);
    if (tempfac == 0X0A) // �������Ѿ�У׼����
    {
        at24cxx_read_multi_bytes(SAVE_ADDR_BASE,(u8 *)&tempfac, 4);
        rt_thread_mdelay(10);
        tftlcd.tp.xfac = (float)tempfac / 100000000; // �õ�xУ׼����
        at24cxx_read_multi_bytes(SAVE_ADDR_BASE + 4,(u8 *)&tempfac, 4);
        rt_thread_mdelay(10);
        tftlcd.tp.yfac = (float)tempfac / 100000000; // �õ�yУ׼����
        // �õ�xƫ����
        at24cxx_read_multi_bytes(SAVE_ADDR_BASE + 8,(u8 *)&tftlcd.tp.xoff, 2);
        rt_thread_mdelay(10);
        // �õ�yƫ����
        at24cxx_read_multi_bytes(SAVE_ADDR_BASE + 10,(u8 *)&tftlcd.tp.yoff, 2);
        rt_thread_mdelay(10);
        tftlcd.tp.type = at24cxx_read_byte(SAVE_ADDR_BASE + 12); // ��ȡ�������ͱ��
        if (tftlcd.tp.type)                                    // X,Y��������Ļ�෴
        {
            CMD_RDX = 0X90;
            CMD_RDY = 0XD0;
        }
        else // X,Y��������Ļ��ͬ
        {
            CMD_RDX = 0XD0;
            CMD_RDY = 0X90;
        }
        return 1;
    }
    return 0;
}

void tpad_draw_point(uint16_t x, uint16_t y, uint16_t color)
{
    tftlcd.point_color = color;
    ili9341_draw_line(x - 12, y, x + 13, y); // ����
    ili9341_draw_line(x, y - 12, x, y + 13); // ����
    ili9341_draw_point(x + 1, y + 1);
    ili9341_draw_point(x - 1, y + 1);
    ili9341_draw_point(x + 1, y - 1);
    ili9341_draw_point(x - 1, y - 1);
    ili9341_draw_circle(x, y, 6); // ������Ȧ
}

void tpad_draw_big_point(uint16_t x, uint16_t y, uint16_t color)
{
    tftlcd.point_color = color;
    ili9341_draw_point(x, y); // ���ĵ�
    ili9341_draw_point(x + 1, y);
    ili9341_draw_point(x, y + 1);
    ili9341_draw_point(x + 1, y + 1);
}
// ��ʾ�ַ���
const char *TP_REMIND_MSG_TBL = "Please use the stylus click the cross on the screen.The cross will always move until the screen adjustment is completed.";

void tpad_adjust(void)
{
    uint16_t pos_temp[4][2]; // ���껺��ֵ
    uint8_t cnt = 0;
    uint16_t d1, d2;
    uint32_t tem1, tem2;
    double fac;
    uint16_t outtime = 0;
    cnt = 0;
    tftlcd.point_color = BLUE;
    tftlcd.back_color = WHITE;
    ili9341_clear(WHITE);     // ����
    tftlcd.point_color = RED; // ��ɫ
    ili9341_clear(WHITE);     // ����
    tftlcd.point_color = BLACK;
    ili9341_show_string(40, 40, 160, 100, 16, (char *)TP_REMIND_MSG_TBL); // ��ʾ��ʾ��Ϣ
    tpad_draw_point(20, 20, RED);                                         // ����1
    tftlcd.tp.sta = 0;                                                    // ���������ź�
    tftlcd.tp.xfac = 0;                                                   // xfac��������Ƿ�У׼��,����У׼֮ǰ�������!�������
    while (1)                                                             // �������10����û�а���,���Զ��˳�
    {
        tftlcd.tp.scan(1);                          // ɨ����������
        if ((tftlcd.tp.sta & 0xc0) == TP_CATH_PRES) // ����������һ��(��ʱ�����ɿ���.)
        {
            outtime = 0;
            tftlcd.tp.sta &= ~(1 << 6); // ��ǰ����Ѿ�����������.

            pos_temp[cnt][0] = tftlcd.tp.x[0];
            pos_temp[cnt][1] = tftlcd.tp.y[0];
            cnt++;
            switch (cnt)
            {
            case 1:
                tpad_draw_point(20, 20, WHITE);              // �����1
                tpad_draw_point(tftlcd.width - 20, 20, RED); // ����2
                break;
            case 2:
                tpad_draw_point(tftlcd.width - 20, 20, WHITE); // �����2
                tpad_draw_point(20, tftlcd.height - 20, RED);  // ����3
                break;
            case 3:
                tpad_draw_point(20, tftlcd.height - 20, WHITE);              // �����3
                tpad_draw_point(tftlcd.width - 20, tftlcd.height - 20, RED); // ����4
                break;
            case 4: // ȫ���ĸ����Ѿ��õ�
                // �Ա����
                tem1 = abs(pos_temp[0][0] - pos_temp[1][0]); // x1-x2
                tem2 = abs(pos_temp[0][1] - pos_temp[1][1]); // y1-y2
                tem1 *= tem1;
                tem2 *= tem2;
                d1 = sqrt(tem1 + tem2); // �õ�1,2�ľ���

                tem1 = abs(pos_temp[2][0] - pos_temp[3][0]); // x3-x4
                tem2 = abs(pos_temp[2][1] - pos_temp[3][1]); // y3-y4
                tem1 *= tem1;
                tem2 *= tem2;
                d2 = sqrt(tem1 + tem2); // �õ�3,4�ľ���
                fac = (float)d1 / d2;
                if (fac < 0.95 || fac > 1.05 || d1 == 0 || d2 == 0) // ���ϸ�
                {
                    cnt = 0;
                    tpad_draw_point(tftlcd.width - 20, tftlcd.height - 20, WHITE);                                                                                                     // �����4
                    tpad_draw_point(20, 20, RED);                                                                                                                                      // ����1
                    tpad_show_adjust_param(pos_temp[0][0], pos_temp[0][1], pos_temp[1][0], pos_temp[1][1], pos_temp[2][0], pos_temp[2][1], pos_temp[3][0], pos_temp[3][1], fac * 100); // ��ʾ����
                    continue;
                }
                tem1 = abs(pos_temp[0][0] - pos_temp[2][0]); // x1-x3
                tem2 = abs(pos_temp[0][1] - pos_temp[2][1]); // y1-y3
                tem1 *= tem1;
                tem2 *= tem2;
                d1 = sqrt(tem1 + tem2); // �õ�1,3�ľ���

                tem1 = abs(pos_temp[1][0] - pos_temp[3][0]); // x2-x4
                tem2 = abs(pos_temp[1][1] - pos_temp[3][1]); // y2-y4
                tem1 *= tem1;
                tem2 *= tem2;
                d2 = sqrt(tem1 + tem2); // �õ�2,4�ľ���
                fac = (float)d1 / d2;
                if (fac < 0.95 || fac > 1.05) // ���ϸ�
                {
                    cnt = 0;
                    tpad_draw_point(tftlcd.width - 20, tftlcd.height - 20, WHITE);                                                                                                     // �����4
                    tpad_draw_point(20, 20, RED);                                                                                                                                      // ����1
                    tpad_show_adjust_param(pos_temp[0][0], pos_temp[0][1], pos_temp[1][0], pos_temp[1][1], pos_temp[2][0], pos_temp[2][1], pos_temp[3][0], pos_temp[3][1], fac * 100); // ��ʾ����
                    continue;
                } // ��ȷ��

                // �Խ������
                tem1 = abs(pos_temp[1][0] - pos_temp[2][0]); // x1-x3
                tem2 = abs(pos_temp[1][1] - pos_temp[2][1]); // y1-y3
                tem1 *= tem1;
                tem2 *= tem2;
                d1 = sqrt(tem1 + tem2); // �õ�1,4�ľ���

                tem1 = abs(pos_temp[0][0] - pos_temp[3][0]); // x2-x4
                tem2 = abs(pos_temp[0][1] - pos_temp[3][1]); // y2-y4
                tem1 *= tem1;
                tem2 *= tem2;
                d2 = sqrt(tem1 + tem2); // �õ�2,3�ľ���
                fac = (float)d1 / d2;
                if (fac < 0.95 || fac > 1.05) // ���ϸ�
                {
                    cnt = 0;
                    tpad_draw_point(tftlcd.width - 20, tftlcd.height - 20, WHITE);                                                                                                     // �����4
                    tpad_draw_point(20, 20, RED);                                                                                                                                      // ����1
                    tpad_show_adjust_param(pos_temp[0][0], pos_temp[0][1], pos_temp[1][0], pos_temp[1][1], pos_temp[2][0], pos_temp[2][1], pos_temp[3][0], pos_temp[3][1], fac * 100); // ��ʾ����
                    continue;
                } // ��ȷ��
                // ������
                tftlcd.tp.xfac = (float)(tftlcd.width - 40) / (pos_temp[1][0] - pos_temp[0][0]);          // �õ�xfac
                tftlcd.tp.xoff = (tftlcd.width - tftlcd.tp.xfac * (pos_temp[1][0] + pos_temp[0][0])) / 2; // �õ�xoff

                tftlcd.tp.yfac = (float)(tftlcd.height - 40) / (pos_temp[2][1] - pos_temp[0][1]);          // �õ�yfac
                tftlcd.tp.yoff = (tftlcd.height - tftlcd.tp.yfac * (pos_temp[2][1] + pos_temp[0][1])) / 2; // �õ�yoff
                if (abs(tftlcd.tp.xfac) > 2 || abs(tftlcd.tp.yfac) > 2)                                    // ������Ԥ����෴��.
                {
                    cnt = 0;
                    tpad_draw_point(tftlcd.width - 20, tftlcd.height - 20, WHITE); // �����4
                    tpad_draw_point(20, 20, RED);                                  // ����1
                    ili9341_show_string(40, 26, tftlcd.width, tftlcd.height, 16, "TP Need readjust!");
                    tftlcd.tp.type = !tftlcd.tp.type; // �޸Ĵ�������.
                    if (tftlcd.tp.type)               // X,Y��������Ļ�෴
                    {
                        CMD_RDX = 0X90;
                        CMD_RDY = 0XD0;
                    }
                    else // X,Y��������Ļ��ͬ
                    {
                        CMD_RDX = 0XD0;
                        CMD_RDY = 0X90;
                    }
                    continue;
                }
                tftlcd.point_color = BLUE;
                ili9341_clear(WHITE);                                                                     // ����
                ili9341_show_string(35, 110, tftlcd.width, tftlcd.height, 16, "Touch Screen Adjust OK!"); // У�����
                for (uint32_t i = 0; i < 100000; i++)
                    tp_delay(10);
                tpad_save_adjust_param();
                ili9341_clear(WHITE); // ����
                return;               // У�����
            }
        }
        for (uint16_t i = 0; i < 1000; i++)
            tp_delay(10);
        outtime++;
        if (outtime > 1000)
        {
            tpad_get_adjust_param();
            break;
        }
    }
}

void tpad_show_adjust_param(uint16_t x0, uint16_t y0, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t x3, uint16_t y3, uint16_t fac)
{
    tftlcd.point_color = RED;
    ili9341_show_string(40, 160, tftlcd.width, tftlcd.height, 16, "x1:");
    ili9341_show_string(40 + 80, 160, tftlcd.width, tftlcd.height, 16, "y1:");
    ili9341_show_string(40, 180, tftlcd.width, tftlcd.height, 16, "x2:");
    ili9341_show_string(40 + 80, 180, tftlcd.width, tftlcd.height, 16, "y2:");
    ili9341_show_string(40, 200, tftlcd.width, tftlcd.height, 16, "x3:");
    ili9341_show_string(40 + 80, 200, tftlcd.width, tftlcd.height, 16, "y3:");
    ili9341_show_string(40, 220, tftlcd.width, tftlcd.height, 16, "x4:");
    ili9341_show_string(40 + 80, 220, tftlcd.width, tftlcd.height, 16, "y4:");
    ili9341_show_string(40, 240, tftlcd.width, tftlcd.height, 16, "fac is:");
    ili9341_show_num(40 + 24, 160, x0, 4, 16);      // ��ʾ��ֵ
    ili9341_show_num(40 + 24 + 80, 160, y0, 4, 16); // ��ʾ��ֵ
    ili9341_show_num(40 + 24, 180, x1, 4, 16);      // ��ʾ��ֵ
    ili9341_show_num(40 + 24 + 80, 180, y1, 4, 16); // ��ʾ��ֵ
    ili9341_show_num(40 + 24, 200, x2, 4, 16);      // ��ʾ��ֵ
    ili9341_show_num(40 + 24 + 80, 200, y2, 4, 16); // ��ʾ��ֵ
    ili9341_show_num(40 + 24, 220, x3, 4, 16);      // ��ʾ��ֵ
    ili9341_show_num(40 + 24 + 80, 220, y3, 4, 16); // ��ʾ��ֵ
    ili9341_show_num(40 + 56, 240, fac, 3, 16);     // ��ʾ��ֵ,����ֵ������95~105��Χ֮��.
}

uint8_t tpad_scan(uint8_t tp)
{
    if (T_PEN == 0) // �а�������
    {
        if (tp)
            tpad_read_x_and_y_average(&tftlcd.tp.x[0], &tftlcd.tp.y[0]);      // ��ȡ��������
        else if (tpad_read_x_and_y_average(&tftlcd.tp.x[0], &tftlcd.tp.y[0])) // ��ȡ��Ļ����
        {
            tftlcd.tp.x[0] = tftlcd.tp.xfac * tftlcd.tp.x[0] + tftlcd.tp.xoff; // �����ת��Ϊ��Ļ����
            tftlcd.tp.y[0] = tftlcd.tp.yfac * tftlcd.tp.y[0] + tftlcd.tp.yoff;
        }
        if ((tftlcd.tp.sta & TP_PRES_DOWN) == 0) // ֮ǰû�б�����
        {
            tftlcd.tp.sta = TP_PRES_DOWN | TP_CATH_PRES; // ��������
            tftlcd.tp.x[4] = tftlcd.tp.x[0];             // ��¼��һ�ΰ���ʱ������
            tftlcd.tp.y[4] = tftlcd.tp.y[0];
        }
    }
    else
    {
        if (tftlcd.tp.sta & TP_PRES_DOWN) // ֮ǰ�Ǳ����µ�
        {
            tftlcd.tp.sta &= ~(1 << 7); // ��ǰ����ɿ�
        }
        else // ֮ǰ��û�б�����
        {
            tftlcd.tp.x[4] = 0;
            tftlcd.tp.y[4] = 0;
            tftlcd.tp.x[0] = 0xffff;
            tftlcd.tp.y[0] = 0xffff;
        }
    }
    return tftlcd.tp.sta & TP_PRES_DOWN; // ���ص�ǰ�Ĵ���״̬
}
