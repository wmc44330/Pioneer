/*
 * ili9341.c
 *
 *  Created on: 2024��11��19��
 *      Author: WangMC
 */
#include "ili9341.h"
#include "font.h"
#include <math.h>
#include <rtthread.h>

#define ILI_DEBUG(fmt, ...)
// #define ILI_DEBUG(fmt, ...) printf(fmt, ##__VA_ARGS__)

lcd_t tftlcd = {
    .wramcmd = 0X2C,
    .setxcmd = 0X2A,
    .setycmd = 0X2B,
    .point_color = RED,
    .back_color = WHITE,
#if defined (DRIVERS_XPT2046_H_)
    .tp = {0},
    .tp.init = tpad_init,
    .tp.scan = tpad_scan,
    .tp.adjust = tpad_adjust,
#endif
};


int ili9341_init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;         // PB4 �������,���Ʊ���
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;     // ��ͨ���ģʽ
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; // 100MHz
    GPIO_Init(GPIOB, &GPIO_InitStructure);            // ��ʼ�� //PG7 �������,���Ʊ���

    fsmc_init();

    // ����9341 ID�Ķ�ȡ
    lcd_write_reg(0XD3);
    tftlcd.id = lcd_read_data(); // dummy read
    tftlcd.id = lcd_read_data(); // ����0X00
    tftlcd.id = lcd_read_data(); // ��ȡ93
    tftlcd.id <<= 8;
    tftlcd.id |= lcd_read_data(); // ��ȡ41

    if (tftlcd.id == 0X9341)
    {
        // ��������дʱ����ƼĴ�����ʱ��
        FSMC_Bank1E->BWTR[6] &= ~(0XF << 0); // ��ַ����ʱ��(ADDSET)����
        FSMC_Bank1E->BWTR[6] &= ~(0XF << 8); // ���ݱ���ʱ������
        FSMC_Bank1E->BWTR[6] |= 3 << 0;      // ��ַ����ʱ��(ADDSET)Ϊ3��HCLK =18ns
        FSMC_Bank1E->BWTR[6] |= 2 << 8;      // ���ݱ���ʱ��(DATAST)Ϊ6ns*3��HCLK=18ns

        lcd_write_reg(0xCF);
        lcd_write_data(0x00);
        lcd_write_data(0xC1);
        lcd_write_data(0X30);
        lcd_write_reg(0xED);
        lcd_write_data(0x64);
        lcd_write_data(0x03);
        lcd_write_data(0X12);
        lcd_write_data(0X81);
        lcd_write_reg(0xE8);
        lcd_write_data(0x85);
        lcd_write_data(0x10);
        lcd_write_data(0x7A);
        lcd_write_reg(0xCB);
        lcd_write_data(0x39);
        lcd_write_data(0x2C);
        lcd_write_data(0x00);
        lcd_write_data(0x34);
        lcd_write_data(0x02);
        lcd_write_reg(0xF7);
        lcd_write_data(0x20);
        lcd_write_reg(0xEA);
        lcd_write_data(0x00);
        lcd_write_data(0x00);
        lcd_write_reg(0xC0);  // Power control
        lcd_write_data(0x1B); // VRH[5:0]
        lcd_write_reg(0xC1);  // Power control
        lcd_write_data(0x01); // SAP[2:0];BT[3:0]
        lcd_write_reg(0xC5);  // VCM control
        lcd_write_data(0x30); // 3F
        lcd_write_data(0x30); // 3C
        lcd_write_reg(0xC7);  // VCM control2
        lcd_write_data(0XB7);
        lcd_write_reg(0x36); // Memory Access Control
        lcd_write_data(0x48);
        lcd_write_reg(0x3A);
        lcd_write_data(0x55);
        lcd_write_reg(0xB1);
        lcd_write_data(0x00);
        lcd_write_data(0x1A);
        lcd_write_reg(0xB6); // Display Function Control
        lcd_write_data(0x0A);
        lcd_write_data(0xA2);
        lcd_write_reg(0xF2); // 3Gamma Function Disable
        lcd_write_data(0x00);
        lcd_write_reg(0x26); // Gamma curve selected
        lcd_write_data(0x01);
        lcd_write_reg(0xE0); // Set Gamma
        lcd_write_data(0x0F);
        lcd_write_data(0x2A);
        lcd_write_data(0x28);
        lcd_write_data(0x08);
        lcd_write_data(0x0E);
        lcd_write_data(0x08);
        lcd_write_data(0x54);
        lcd_write_data(0XA9);
        lcd_write_data(0x43);
        lcd_write_data(0x0A);
        lcd_write_data(0x0F);
        lcd_write_data(0x00);
        lcd_write_data(0x00);
        lcd_write_data(0x00);
        lcd_write_data(0x00);
        lcd_write_reg(0XE1); // Set Gamma
        lcd_write_data(0x00);
        lcd_write_data(0x15);
        lcd_write_data(0x17);
        lcd_write_data(0x07);
        lcd_write_data(0x11);
        lcd_write_data(0x06);
        lcd_write_data(0x2B);
        lcd_write_data(0x56);
        lcd_write_data(0x3C);
        lcd_write_data(0x05);
        lcd_write_data(0x10);
        lcd_write_data(0x0F);
        lcd_write_data(0x3F);
        lcd_write_data(0x3F);
        lcd_write_data(0x0F);
        lcd_write_reg(0x2B);
        lcd_write_data(0x00);
        lcd_write_data(0x00);
        lcd_write_data(0x01);
        lcd_write_data(0x3f);
        lcd_write_reg(0x2A);
        lcd_write_data(0x00);
        lcd_write_data(0x00);
        lcd_write_data(0x00);
        lcd_write_data(0xef);
        lcd_write_reg(0x11); // Exit Sleep
        opt_delay(50);
        lcd_write_reg(0x29); // display on
    }
    ILI_DEBUG("LCD ID : %X\n", tftlcd.id);
    ili9341_set_display_dir(0); // ��������
    LCD_BL(1);
    ili9341_clear(WHITE);
    return 0;
}
INIT_BOARD_EXPORT(ili9341_init);

void ili9341_set_display_dir(uint8_t dir)
{
    tftlcd.dir = dir;
    if (dir == 0)
    { // ����
        tftlcd.width = 240;
        tftlcd.height = 320;
    }
    else
    {
        tftlcd.width = 320;
        tftlcd.height = 240;
    }
    ili9341_set_scan_dir(DFT_SCAN_DIR);
}

void ili9341_set_scan_dir(uint8_t dir)
{
    uint16_t regval = 0;
    uint16_t dirreg = 0;
    uint16_t temp;
    if ((tftlcd.dir == 1 && tftlcd.id == 0X9341)) // ����ʱ����6804��1963���ı�ɨ�跽������ʱ1963�ı䷽��
    {
        switch (dir) // ����ת��
        {
        case 0:
            dir = 6;
            break;
        case 1:
            dir = 7;
            break;
        case 2:
            dir = 4;
            break;
        case 3:
            dir = 5;
            break;
        case 4:
            dir = 1;
            break;
        case 5:
            dir = 0;
            break;
        case 6:
            dir = 3;
            break;
        case 7:
            dir = 2;
            break;
        }
    }
    switch (dir)
    {
    case L2R_U2D: // ������,���ϵ���
        regval |= (0 << 7) | (0 << 6) | (0 << 5);
        break;
    case L2R_D2U: // ������,���µ���
        regval |= (1 << 7) | (0 << 6) | (0 << 5);
        break;
    case R2L_U2D: // ���ҵ���,���ϵ���
        regval |= (0 << 7) | (1 << 6) | (0 << 5);
        break;
    case R2L_D2U: // ���ҵ���,���µ���
        regval |= (1 << 7) | (1 << 6) | (0 << 5);
        break;
    case U2D_L2R: // ���ϵ���,������
        regval |= (0 << 7) | (0 << 6) | (1 << 5);
        break;
    case U2D_R2L: // ���ϵ���,���ҵ���
        regval |= (0 << 7) | (1 << 6) | (1 << 5);
        break;
    case D2U_L2R: // ���µ���,������
        regval |= (1 << 7) | (0 << 6) | (1 << 5);
        break;
    case D2U_R2L: // ���µ���,���ҵ���
        regval |= (1 << 7) | (1 << 6) | (1 << 5);
        break;
    }
    dirreg = 0X36;
    regval |= 0X08;
    lcd_write_reg_data(dirreg, regval);
    if (tftlcd.id != 0X1963) // 1963�������괦��
    {
        if (regval & 0X20)
        {
            if (tftlcd.width < tftlcd.height) // ����X,Y
            {
                temp = tftlcd.width;
                tftlcd.width = tftlcd.height;
                tftlcd.height = temp;
            }
        }
        else
        {
            if (tftlcd.width > tftlcd.height) // ����X,Y
            {
                temp = tftlcd.width;
                tftlcd.width = tftlcd.height;
                tftlcd.height = temp;
            }
        }
    }

    lcd_write_reg(tftlcd.setxcmd);
    lcd_write_data(0);
    lcd_write_data(0);
    lcd_write_data((tftlcd.width - 1) >> 8);
    lcd_write_data((tftlcd.width - 1) & 0XFF);
    lcd_write_reg(tftlcd.setycmd);
    lcd_write_data(0);
    lcd_write_data(0);
    lcd_write_data((tftlcd.height - 1) >> 8);
    lcd_write_data((tftlcd.height - 1) & 0XFF);
}

void ili9341_clear(uint16_t color)
{
    uint32_t index = 0;
    uint32_t totalpoint = tftlcd.width;
    totalpoint *= tftlcd.height;      // �õ��ܵ���
    ili9341_set_cursor(0x00, 0x0000); // ���ù��λ��
    lcd_write_gram_reg();             // ��ʼд��GRAM
    for (index = 0; index < totalpoint; index++)
    {
        TFTLCD->data = color;
    }
}

void ili9341_set_cursor(uint16_t Xpos, uint16_t Ypos)
{
    if (tftlcd.id == 0X9341)
    {
        lcd_write_reg(tftlcd.setxcmd);
        lcd_write_data(Xpos >> 8);
        lcd_write_data(Xpos & 0XFF);
        lcd_write_reg(tftlcd.setycmd);
        lcd_write_data(Ypos >> 8);
        lcd_write_data(Ypos & 0XFF);
    }
}

// LCD������ʾ
void ili9341_display_on(void)
{
    if (tftlcd.id == 0X9341)
        lcd_write_reg(0X29);
}

// LCD�ر���ʾ
void ili9341_display_off(void)
{
    if (tftlcd.id == 0X9341)
        lcd_write_reg(0X28);
}
// ����
uint16_t ili9341_read_point(uint16_t x, uint16_t y)
{

    uint16_t r = 0, g = 0, b = 0;
    if (x >= tftlcd.width || y >= tftlcd.height)
        return 0; // �����˷�Χ,ֱ�ӷ���
    ili9341_set_cursor(x, y);
    lcd_write_reg(0X2E); // 9341/6804/3510/1963 ���Ͷ�GRAMָ��

    r = lcd_read_data(); // dummy Read
    opt_delay(2);
    r = lcd_read_data(); // ʵ��������ɫ
    opt_delay(2);
    b = lcd_read_data();
    g = r & 0XFF; // ����9341/5310/5510,��һ�ζ�ȡ����RG��ֵ,R��ǰ,G�ں�,��ռ8λ
    g <<= 8;

    return (((r >> 11) << 11) | ((g >> 10) << 5) | (b >> 11)); // ILI9341/NT35310/NT35510��Ҫ��ʽת��һ��
}

// ����
void ili9341_draw_point(uint16_t x, uint16_t y)
{
    ili9341_set_cursor(x, y); // ���ù��λ��
    lcd_write_gram_reg();     // ��ʼд��GRAM
    TFTLCD->data = tftlcd.point_color;
}

void ili9341_fast_draw_point(uint16_t x, uint16_t y, uint16_t color)
{
    if (tftlcd.id == 0X9341)
    {
        lcd_write_reg(tftlcd.setxcmd);
        lcd_write_data(x >> 8);
        lcd_write_data(x & 0XFF);
        lcd_write_reg(tftlcd.setycmd);
        lcd_write_data(y >> 8);
        lcd_write_data(y & 0XFF);
    }
    TFTLCD->reg = tftlcd.wramcmd;
    TFTLCD->data = color;
}

void ili9341_set_window(uint16_t sx, uint16_t sy, uint16_t width, uint16_t height)
{
    uint16_t twidth, theight;
    twidth = sx + width - 1;
    theight = sy + height - 1;
    if (tftlcd.id == 0X9341)
    {
        lcd_write_reg(tftlcd.setxcmd);
        lcd_write_data(sx >> 8);
        lcd_write_data(sx & 0XFF);
        lcd_write_data(twidth >> 8);
        lcd_write_data(twidth & 0XFF);
        lcd_write_reg(tftlcd.setycmd);
        lcd_write_data(sy >> 8);
        lcd_write_data(sy & 0XFF);
        lcd_write_data(theight >> 8);
        lcd_write_data(theight & 0XFF);
    }
}

void ili9341_fill(uint16_t sx, uint16_t sy, uint16_t ex, uint16_t ey, uint16_t color)
{
    uint16_t i, j;
    uint16_t xlen = 0;
    if (tftlcd.id == 0X9341)
    {
        xlen = ex - sx + 1;
        for (i = sy; i <= ey; i++)
        {
            ili9341_set_cursor(sx, i); // ���ù��λ��
            lcd_write_gram_reg();      // ��ʼд��GRAM
            for (j = 0; j < xlen; j++)
                TFTLCD->data = color; // ��ʾ��ɫ
        }
    }
}

void ili9341_color_fill(uint16_t sx, uint16_t sy, uint16_t ex, uint16_t ey, uint16_t *color)
{
    uint16_t height, width;
    uint16_t i, j;
    width = ex - sx + 1;  // �õ����Ŀ���
    height = ey - sy + 1; // �߶�
    for (i = 0; i < height; i++)
    {
        ili9341_set_cursor(sx, sy + i); // ���ù��λ��
        lcd_write_gram_reg();           // ��ʼд��GRAM
        for (j = 0; j < width; j++)
            TFTLCD->data = color[i * width + j]; // д������
    }
}

void ili9341_draw_line(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
    uint16_t t;
    int xerr = 0, yerr = 0, delta_x, delta_y, distance;
    int incx, incy, uRow, uCol;
    delta_x = x2 - x1; // ������������
    delta_y = y2 - y1;
    uRow = x1;
    uCol = y1;
    if (delta_x > 0)
        incx = 1; // ���õ�������
    else if (delta_x == 0)
        incx = 0; // ��ֱ��
    else
    {
        incx = -1;
        delta_x = -delta_x;
    }
    if (delta_y > 0)
        incy = 1;
    else if (delta_y == 0)
        incy = 0; // ˮƽ��
    else
    {
        incy = -1;
        delta_y = -delta_y;
    }
    if (delta_x > delta_y)
        distance = delta_x; // ѡȡ��������������
    else
        distance = delta_y;
    for (t = 0; t <= distance + 1; t++) // �������
    {
        ili9341_draw_point(uRow, uCol); // ����
        xerr += delta_x;
        yerr += delta_y;
        if (xerr > distance)
        {
            xerr -= distance;
            uRow += incx;
        }
        if (yerr > distance)
        {
            yerr -= distance;
            uCol += incy;
        }
    }
}

void ili9341_draw_rect(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
    ili9341_draw_line(x1, y1, x2, y1);
    ili9341_draw_line(x1, y1, x1, y2);
    ili9341_draw_line(x1, y2, x2, y2);
    ili9341_draw_line(x2, y1, x2, y2);
}

void ili9341_draw_circle(uint16_t x0, uint16_t y0, uint8_t r)
{
    int a, b;
    int di;
    a = 0;
    b = r;
    di = 3 - (r << 1); // �ж��¸���λ�õı�־
    while (a <= b)
    {
        ili9341_draw_point(x0 + a, y0 - b); // 5
        ili9341_draw_point(x0 + b, y0 - a); // 0
        ili9341_draw_point(x0 + b, y0 + a); // 4
        ili9341_draw_point(x0 + a, y0 + b); // 6
        ili9341_draw_point(x0 - a, y0 + b); // 1
        ili9341_draw_point(x0 - b, y0 + a);
        ili9341_draw_point(x0 - a, y0 - b); // 2
        ili9341_draw_point(x0 - b, y0 - a); // 7
        a++;
        // ʹ��Bresenham�㷨��Բ
        if (di < 0)
            di += 4 * a + 6;
        else
        {
            di += 10 + 4 * (a - b);
            b--;
        }
    }
}

// mode:���ӷ�ʽ(1)���Ƿǵ��ӷ�ʽ(0)
void ili9341_show_char(uint16_t x, uint16_t y, uint8_t chr, uint8_t size, uint8_t mode)
{
    uint8_t temp, t1, t;
    uint16_t y0 = y;
    uint8_t csize = (size / 8 + ((size % 8) ? 1 : 0)) * (size / 2); // �õ�����һ���ַ���Ӧ������ռ���ֽ���
    chr = chr - ' ';                                                // �õ�ƫ�ƺ��ֵ��ASCII�ֿ��Ǵӿո�ʼȡģ������-' '���Ƕ�Ӧ�ַ����ֿ⣩
    for (t = 0; t < csize; t++)
    {
        if (size == 12)
            temp = asc2_1206[chr][t]; // ����1206����
        else if (size == 16)
            temp = asc2_1608[chr][t]; // ����1608����
        else if (size == 24)
            temp = asc2_2412[chr][t]; // ����2412����
        else
            return; // û�е��ֿ�
        for (t1 = 0; t1 < 8; t1++)
        {
            if (temp & 0x80)
                ili9341_fast_draw_point(x, y, tftlcd.point_color);
            else if (mode == 0)
                ili9341_fast_draw_point(x, y, tftlcd.back_color);
            temp <<= 1;
            y++;
            if (y >= tftlcd.height)
                return; // ��������
            if ((y - y0) == size)
            {
                y = y0;
                x++;
                if (x >= tftlcd.width)
                    return; // ��������
                break;
            }
        }
    }
}

void ili9341_show_num(uint16_t x, uint16_t y, uint32_t num, uint8_t len, uint8_t size)
{
    uint8_t t, temp;
    uint8_t enshow = 0;
    for (t = 0; t < len; t++)
    {
        temp = (num / (uint32_t)pow(10, len - t - 1)) % 10;
        if (enshow == 0 && t < (len - 1))
        {
            if (temp == 0)
            {
                ili9341_show_char(x + (size / 2) * t, y, ' ', size, 0);
                continue;
            }
            else
                enshow = 1;
        }
        ili9341_show_char(x + (size / 2) * t, y, temp + '0', size, 0);
    }
}

// ��ʾ����,��λΪ0,������ʾ
// x,y:�������
// num:��ֵ(0~999999999);
// len:����(��Ҫ��ʾ��λ��)
// size:�����С
// mode:
//[7]:0,�����;1,���0.
//[6:1]:����
//[0]:0,�ǵ�����ʾ;1,������ʾ.
void ili9341_show_xnum(uint16_t x, uint16_t y, uint32_t num, uint8_t len, uint8_t size, uint8_t mode)
{
    uint8_t t, temp;
    uint8_t enshow = 0;
    for (t = 0; t < len; t++)
    {
        temp = (num / (uint32_t)pow(10, len - t - 1)) % 10;
        if (enshow == 0 && t < (len - 1))
        {
            if (temp == 0)
            {
                if (mode & 0X80)
                    ili9341_show_char(x + (size / 2) * t, y, '0', size, mode & 0X01);
                else
                    ili9341_show_char(x + (size / 2) * t, y, ' ', size, mode & 0X01);
                continue;
            }
            else
                enshow = 1;
        }
        ili9341_show_char(x + (size / 2) * t, y, temp + '0', size, mode & 0X01);
    }
}

// ��ʾ�ַ���
// x,y:�������
// width,height:�����С
// size:�����С
//*p:�ַ�����ʼ��ַ
void ili9341_show_string(uint16_t x, uint16_t y, uint16_t width, uint16_t height, uint8_t size, char *p)
{
    uint8_t x0 = x;
    width += x;
    height += y;
    while ((*p <= '~') && (*p >= ' ')) // �ж��ǲ��ǷǷ��ַ�!
    {
        if (x >= width)
        {
            x = x0;
            y += size;
        }
        if (y >= height)
            break; // �˳�
        ili9341_show_char(x, y, *p, size, 0);
        x += size / 2;
        p++;
    }
}

void ili9341_show_test(void)
{
    ili9341_draw_rect(0, 0, 100, 100);
    ili9341_draw_circle(100, 100, 50);
    tftlcd.point_color = BLUE;
    ili9341_show_string(0, 240, 240, 16, 16, "Hello , ILI9341!");
    ili9341_show_xnum(0, 260, 482544330, 9, 16, 0);
    tftlcd.point_color = BLACK;
    ili9341_draw_line(10, 200, 200, 50);
    tftlcd.point_color = GREEN;
    ili9341_fill(170, 150, 220, 260, tftlcd.point_color);
    tftlcd.point_color = LIGHTBLUE;
    ili9341_set_window(60, 160, 80, 50);
}

